
typedef double (*pfn) (double); 
double trapezoidal(double a, double b, pfn f, int n);
